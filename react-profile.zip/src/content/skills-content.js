import React from "react";

export default class SkillsContent extends React.Component {
  render() {
    return (
      <div id="Skills">
        <p>YEAHSSSSSSSSSSSSS</p>
      </div>
    );
  }
}
