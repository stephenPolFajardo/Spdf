import React, { Component } from "react";

class ObjectiveContent extends Component {
  render() {
    return (
      <div id="Objective" class="tabcontent">
        <p>
          To take up any challenging position when my <span id="dots">...</span>
          <span id="more">
            knowledge can be utilized for the maximum benefit of the
            organization. Open to new ideas and an attitude as well as potential
            to group and implement new technologies.
          </span>
        </p>
        <div class="btn">
          <button onclick="myFunction()" id="myBtn">
            Read more
          </button>
        </div>
      </div>
    );
  }
}

export default ObjectiveContent;
