import React from "react";
import ReactDOM from "react-dom";
import "bootstrap/dist/css/bootstrap.min.css";

import "./styles.css";
import BodyContainer from "./body";
import NavBar from "./nav-bar";

function App() {
  return (
    <div className="App">
      <BodyContainer />
      <NavBar />
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
