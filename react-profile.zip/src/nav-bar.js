import React from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import ObjectiveContent from "./content/objective";
import SkillsContent from "./content/skills-content";
import ProjectsContent from "./content/projects-content";

function NavBar() {
  return (
    <Router>
      <ul className="nav nav-pills nav-fill">
        <li className="nav-item">
          <Link className="nav-link active" to="/objective">
            Objective
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/skills">
            Skills
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/projects">
            Projects
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link disabled" to="#">
            Contact
          </Link>
        </li>
      </ul>
      <div className="container">
        <br />
        <Route exact path="/objective" component={ObjectiveContent} />
        <Route path="/skills" component={SkillsContent} />
        <Route path="/projects" component={ProjectsContent} />
      </div>
    </Router>
  );
}

export default NavBar;
