import React, { Component } from "react";

export default class BodyContainer extends Component {
  render() {
    return (
      <div className="container">
        <h1>Stephen Pol Fajardo</h1>
        <h3>Software Engineer</h3>
        <a href="stephen.pdf" download>
          Resume
        </a>
      </div>
    );
  }
}
